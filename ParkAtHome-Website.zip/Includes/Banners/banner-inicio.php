<section class="banner">
    <div class="container">
        <div class="text-center">
            <div class="bannerContent">
                <h1 style="font-size: 36pt;">Park@Home</h1>
                <p style="font-size: 1.4rem;">Estacionar o seu automóvel nunca foi tão fácil.</p>
            </div>
            <div class="d-flex justify-content-center">
                <a style="font-size: 1.0rem" class="btn btn-outline-light px-3 py-2 btnStartNow" href="../Login/" role="button">Começar agora!</a>
            </div>
        </div>
    </div>
</section>