<section class="banner">
    <div class="container">
        <div class="text-center">
            <div class="bannerContent">
                <h1 style="font-size: 36pt;">Parques</h1>
                <p style="font-size: 1.4rem;">Encontre aqui a lista dos nossos parques de estacionamento.</p>
            </div>
            <div class="d-flex justify-content-center">
                <a style="font-size: 1.0rem" class="btn btn-outline-light px-3 py-2 btnStartNow" href="../Login/" role="button">Começar agora!</a>
            </div>
        </div>
    </div>
</section>