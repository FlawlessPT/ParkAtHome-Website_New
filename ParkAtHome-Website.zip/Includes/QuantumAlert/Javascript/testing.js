Qual.sw("Welcome","Nice to meet you",succ,"Submit","Close","hello","bu","text","TEXT");



// Qual.sdh("hello","Help")
var a, b;
// popalert.simple("Hello World")
function hello() {
  a = inx;
  console.log(a);
}

function max() {
  b = inx;
  console.log(b);
}
